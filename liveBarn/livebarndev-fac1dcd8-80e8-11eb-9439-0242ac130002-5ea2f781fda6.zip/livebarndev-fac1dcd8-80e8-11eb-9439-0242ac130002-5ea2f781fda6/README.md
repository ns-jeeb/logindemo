# LiveBarn Android Developer Interview Guide #

Welcome to LiveBarn Android Interview Project Guide. 

In this guide, we'll walk through the project you're going to build with LiveBarn API.

The project aims to display a list with venues and their surfaces, with sports as filter options. In case you're unfamiliar with sports, a `Venue` is like an organization, e.g. McGill University Sports Center, a `Surface` is a certain field in that venue, e.g., a `Gym Center` can be a surface, `McGill Hockey Rink` can be another surface. As you can see, a `Venue` can have multiple surfaces, and each surface has its own name and sport type, e.g., `Gym`, `Hockey`, `Basketball`, `Baseball` etc.

## Complete Project Demo ##

![demo](asset/demo.gif)

![ui](asset/ui.jpg)

## Requirements ##

**Top Sports Horizontal Scroll**

1. Surfaces JSON Data: 
   
      - HTTP `GET` request to:

         ```
         https://2hsjstzo71.execute-api.us-east-1.amazonaws.com/prod/livebarn-interview-project
         ```

      - Sample response of two `Surface` objects.

         ```
         [
           {
             "id": 9,
             "surfaceName": "Rink #1",
             "status": "OK",
             "venueName": "Arena Repentigny",
             "sport": "Hockey",
             "server": {
               "id": 17594,
               "ip4": "0.0.0.17594",
               "dns": "test.server_17594.livebarn.com"
             }
           },
           {
             "id": 15,
             "surfaceName": "Rink #3",
             "status": "OK",
             "venueName": "Complexe Sportif Guimond",
             "sport": "Baseball",
             "server": {
               "id": 17594,
               "ip4": "0.0.0.17594",
               "dns": "test.server_17594.livebarn.com"
             }
           }
         ]
         ```

1. When certain `Sport` is selected, highlight sport name with black color. Surfaces list should scroll to that sport.
   
    - Showing soccer surfaces list
  
       ![soccer](asset/soccer_surfaces.png)

    - Showing basketball surfaces list
    
       ![basketball](asset/basketball_surfaces.png)

    - Sport Horizontal Scroll height should be 1/10 of screen height. Use default platform specific padding for text and edges.
    
       ![height](asset/height.png)


2. `Sport` types may have more than demo `gif`, you should find all sports based on the server response.

**Venue Surfaces List**

1. User could swipe left/right to change sport type and top sport horizontal scroll should update selection accordingly. When scroll up/down, `Venue` name should stick on top for current surfaces.

    ![scroll](asset/scroll.gif)

2. Each section contains `Venue` name and followed by its `Surfaces`.

    ![surfaces](asset/venue_surfaces.png)
    

3. User tap `Surface`, show alert with selected `Surface` name and `Venue` name. If tap `OK`, show video player play the following:
   ```
   https://devstreaming-cdn.apple.com/videos/streaming/examples/bipbop_4x3/bipbop_4x3_variant.m3u8
   ```

    ![alert](asset/alert.png)

4. Venues/Surface list is sorted by alphabetical order of venue name

    ![sort](asset/sort.png)


5. Surface Image

- Even number index, show gray color image: `https:/via.placeholder.com/300/808080`
- Odd number index, show black color image: `https:/via.placeholder.com/300/202020`

    ![surface](asset/surface_image.png)

**Note**

1. All UI components design should follow Google [Material Design](https://material.io/develop/android). Feel free to use default UI components provided by SDK to achieve similar result faster.
2. You can use either `Java`, or preferably `Kotlin`.
3. No third-party lib is allowed.

**Bonus points we value**

1. Covered by Unit Test
2. Clean code/architecture

**Submission**

Push your project to your GitHub or any other Git version control platform and share the repo URL with us.